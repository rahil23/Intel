package Test;

class StringFilter {
	String source = null;

	public String filter(String source, String filter) {
	
		String returnString = source;
		

			for (int j = 0; j < filter.length(); j++) {

				if (returnString.indexOf(filter.charAt(j))!=-1) {

					returnString=returnString.replaceAll(""+filter.charAt(j),"");
				}
				
				
				
			
			
		}
	// System.out.println(returnString);

	return returnString;

}

}

public class StringFilterMain {

	public static void main(String[] args) {
		StringFilter obj = new StringFilter();
		//System.out.println(obj.filter("ABCDE", "BD"));
		 System.out.println(obj.filter("ABCDEFGH", "G"));

		// System.out.println(obj.filter("ABCDE", ""));
		// obj.filter("ABCDE", null);

	}
}
