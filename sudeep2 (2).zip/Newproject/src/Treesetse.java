import java.util.TreeSet;


public class Treesetse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeSet ts= new TreeSet();
ts.add("ravan");
ts.add("bavan");
ts.add("aavan");
ts.add("kavan");

System.out.println(ts);
	}

}
