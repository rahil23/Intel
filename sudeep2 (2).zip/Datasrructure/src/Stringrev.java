
public class Stringrev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ab= "sudeep";
		
		char[] cd= ab.toCharArray();
		
		for(int i=cd.length-1;i>=0;i--){
			System.out.println(cd[i]);
		}

	}

}
