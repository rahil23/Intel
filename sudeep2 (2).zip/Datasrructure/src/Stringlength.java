
public class Stringlength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		String ab= "sudeepsinha";
		
		char[] ch= ab.toCharArray();
		
		for(char c: ch){
			i++;
		}
			System.out.println(i);
		

	}

}
