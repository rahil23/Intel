
public class Practice {
	final static synchronized public void  main(String[]  sudeep){
		System.out.println("validmain");
	}

}
